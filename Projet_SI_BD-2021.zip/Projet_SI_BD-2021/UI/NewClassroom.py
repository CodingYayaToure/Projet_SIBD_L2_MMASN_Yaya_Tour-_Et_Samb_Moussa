from tkinter import *

class NewClassroom:
    def __init__(self):
        # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        # Titre
        label_title = Label(frame, text="Nouvelle salle", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack()
        frame1 = Frame(frame, bg='#41B77F')
        prlab = Label(frame1, text="Libellé", font=("Courrier", 20), bg='#41B77F', fg='white')
        prlab.grid(row=0, column=0, pady=10)
        prEntry = Entry(frame1, font=("Courrier", 20), fg='#41B77F', bg='white')
        prEntry.grid(row=0, column=1, pady=10, padx=5)
        # Sauvegarder
        btn = Button(frame1, text="Enregistrer", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn.config(command=lambda: self.Save(prEntry))
        btn.grid(row=3, column=0, pady=10)
        btn1 = Button(frame1, text="Retour", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn1.config(command=self.Back)
        btn1.grid(row=3, column=1, pady=10, padx=5)
        frame1.pack(expand=YES)
        frame.pack(expand=YES)
        self.window.mainloop()

    def Save(self,prEntry):
        from Elements.Salle import Salle
        Salle(0, prEntry.get()).Save()
        self.Back()

    def Back(self):
        self.window.destroy()
        from UI.Classroom import Classroom
        Classroom()