from tkinter import *

class Delib:
    def __init__(self):
        # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.maxsize(700, 500)
        self.window.config(background='#41B77F')
        main_frame = Frame(self.window, bg='#41B77F')
        main_frame.pack(expand=YES, fill=BOTH)
        label_title = Label(main_frame, text="Menu des cours", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack(fill=X, expand=YES)
        canvas = Canvas(main_frame, bg='#41B77F')

        vscr = Scrollbar(main_frame, orient=VERTICAL, command=canvas.yview)
        vscr.pack(side=RIGHT, fill=Y)
        hscr = Scrollbar(main_frame, orient=HORIZONTAL, command=canvas.xview)
        hscr.pack(side=BOTTOM, fill=X)
        canvas.pack(side=LEFT, fill=BOTH, expand=YES)
        canvas.configure(yscrollcommand=vscr.set, xscrollcommand=hscr.set)
        canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        frame = Frame(canvas, bg='#41B77F')
        canvas.create_window((0, 0), window=frame, anchor='nw')
        header = Frame(frame, bg='green')
        Label(header, text="Nom", font=("Courrier", 20), bg='green', fg='white').grid(row=0, column=0, padx=(10, 50))
        Label(header, text="Niveau", font=("Courrier", 20), bg='green', fg='white').grid(row=0, column=0, padx=(10, 50))
        Label(header, text="Moyenne", font=("Courrier", 20), bg='green', fg='white').grid(row=0, column=1,
                                                                                             padx=(10, 50))
        header.pack(expand=YES, fill=X, padx=10)
        container = Frame(frame, bg='#41B77F')
        i = 1
        for c in Cours(0, '', '', datetime.now(), '', datetime.now()).getCourses():
            Label(container, text=c.getNom(), font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=i, column=0,
                                                                                                    padx=(10, 50))
            Label(container, text=c.getProf(), font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=i, column=1,
                                                                                                     padx=(10, 50))
            Label(container, text=c.getSalle(), font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=i, column=2,
                                                                                                      padx=(10, 50))
            Label(container, text=c.getDate(), font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=i, column=3,
                                                                                                     padx=(10, 50))
            Label(container, text=c.getHoraire(), font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=i, column=4,
                                                                                                        padx=(10, 50))
            i += 1
        container.pack(expand=YES, fill=BOTH)
        btn = Button(self.window, text="Retour", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn.config(command=self.Back)
        btn.pack(expand=YES, pady=10)
        self.window.mainloop()

