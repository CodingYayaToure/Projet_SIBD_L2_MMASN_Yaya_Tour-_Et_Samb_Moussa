from tkinter import *


class StudentSpace:
    def __init__(self):
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        # Titre
        label_title = Label(frame, text="Espace étudiants", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack()
        btn = Button(frame, text="Nouvel étudiant", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn.config(command=self.New)
        btn.pack(pady=(50, 10), fill=X)
        btn1 = Button(frame, text="Liste des étudiants", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn1.config(command=self.List)
        btn1.pack(pady=10, fill=X)
        btn2 = Button(frame, text="Retour", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn2.config(command=self.Back)
        btn2.pack(pady=10, fill=X)
        frame.pack(expand=YES)
        # Affichage
        self.window.mainloop()

    def Back(self):
        self.window.destroy()
        from UI.Personnals import Personnals
        Personnals()

    def New(self):
        self.window.destroy()
        from UI.NewStudent import NewStudent
        NewStudent()

    def List(self):
        self.window.destroy()
        from UI.ListStudents import ListStudents
        ListStudents()