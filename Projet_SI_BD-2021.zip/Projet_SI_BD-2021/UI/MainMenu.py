from datetime import datetime
from tkinter import *
from Elements.Cours import Cours
from Elements.Etudiant import Etudiant
from Elements.Salle import Salle

class MainMenu:
    def __init__(self):
        Etudiant(0,'','','').createStudentTable()
        Salle(0,'').createRoomTable()
        Cours(0,'','',datetime.now(),'',datetime.now()).createCourseTable()
        # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        # Titre
        label_title = Label(frame, text="Gestionnaire d'école", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack()
        btn = Button(frame, text="Espace étude", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn.config(command=self.StudySpace)
        btn.pack(pady=(50, 10), fill=X)
        btn1 = Button(frame, text="Résultats", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn1.pack(pady=10, fill=X)
        btn1.config(command=self.Result)
        btn2 = Button(frame, text="Salles de classe", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn2.pack(pady=10, fill=X)
        btn2.config(command=self.RoomsSpace)
        frame.pack(expand=YES)
        # Affichage
        self.window.mainloop()

    def StudySpace(self):
        self.window.destroy()
        from UI.Personnals import Personnals
        Personnals()

    def Result(self):
        self.window.destroy()
        from UI.Result import Result
        Result()

    def RoomsSpace(self):
        self.window.destroy()
        from UI.Classroom import Classroom
        Classroom()


