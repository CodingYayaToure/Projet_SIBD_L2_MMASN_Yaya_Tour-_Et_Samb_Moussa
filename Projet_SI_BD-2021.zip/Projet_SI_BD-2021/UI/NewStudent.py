from tkinter import *

from Elements.Etudiant import Etudiant


class NewStudent:
    def __init__(self):
        # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        # Titre
        label_title = Label(frame, text="Nouvel étudiant", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack()
        frame1 = Frame(frame, bg='#41B77F')
        prlab = Label(frame1, text="Prénom", font=("Courrier", 20), bg='#41B77F', fg='white')
        prlab.grid(row=0, column=0, pady=10)
        prEntry = Entry(frame1, font=("Courrier", 20), fg='#41B77F', bg='white')
        prEntry.grid(row=0, column=1, pady=10, padx=5)
        nomlab = Label(frame1, text="Nom", font=("Courrier", 20), bg='#41B77F', fg='white', pady=10)
        nomlab.grid(row=1, column=0, pady=10)
        nomEntry = Entry(frame1, font=("Courrier", 20), fg='#41B77F', bg='white')
        nomEntry.grid(row=1, column=1, pady=10, padx=5)
        nivlab = Label(frame1, text="Niveau", font=("Courrier", 20), bg='#41B77F', fg='white', pady=10)
        nivlab.grid(row=2, column=0, pady=10)
        nivEntry = Entry(frame1, font=("Courrier", 20), fg='#41B77F', bg='white')
        nivEntry.grid(row=2, column=1, pady=10, padx=5)
        btn = Button(frame1, text="Valider", font=("Courrier", 20), fg='#41B77F', bg='white')
        # Sauvegarder
        btn.config(command=lambda: self.Save(prEntry, nomEntry, nivEntry))
        btn.grid(row=3, column=0, pady=10)
        btn1 = Button(frame1, text="Retour", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn1.config(command=self.Back)
        btn1.grid(row=3, column=1, pady=10, padx=5)
        frame1.pack(expand=YES)
        frame.pack(expand=YES)
        self.window.mainloop()

    def Save(self, prEntry, nE, niv):
        pr = prEntry.get()
        n = nE.get()
        niv = niv.get()
        Etudiant(1, pr, n, niv).Save()
        self.Back()

    def Back(self):
        self.window.destroy()
        from UI.StudentSpace import StudentSpace
        StudentSpace()
