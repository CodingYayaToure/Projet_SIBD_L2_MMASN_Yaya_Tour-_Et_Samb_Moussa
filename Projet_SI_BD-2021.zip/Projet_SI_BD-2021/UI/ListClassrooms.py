from tkinter import *

class ListClassrooms:
    def __init__(self):
         # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        # Titre
        label_title = Label(frame, text="Liste des salles de classe", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack()
        header = Frame(frame, bg='#006400')
        Label(header, text="Libellé", font=("Courrier", 23), bg='#006400', fg='white').grid(row=0, column=0, padx=(10, 50))
        Label(header, text="Disponibilité", font=("Courrier", 23), bg='#006400', fg='white').grid(row=0, column=1, padx=50,sticky='E')
        header.pack(fill=X, expand=YES)
        scr = Scrollbar(frame, orient="vertical")
        frame1 = Frame(scr, bg='#41B77F')
        i = 1
        from Elements.Salle import Salle
        for e in Salle(0, "").getRooms():
            Label(frame1, text=e.getRoom()["libelle"], font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=i,column=0,padx=(10, 50))
            Label(frame1, text=e.getState(), font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=i,column=1, padx=50,sticky='E')
            i += 1
        frame1.pack(expand=YES, fill=X)
        scr.pack(expand=YES, fill=X)
        btn = Button(frame, text="Retour", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn.config(command=self.Back)
        btn.pack(expand=YES, pady=10)
        frame.pack(expand=YES)
        self.window.mainloop()

    def Back(self):
        self.window.destroy()
        from UI.Classroom import Classroom
        Classroom()