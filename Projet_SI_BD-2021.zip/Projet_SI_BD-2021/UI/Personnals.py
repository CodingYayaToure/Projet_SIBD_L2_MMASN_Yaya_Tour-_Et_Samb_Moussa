from tkinter import *


# Menu Espace étude

class Personnals:
    def __init__(self):
        # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        # Titre
        label_title = Label(frame, text="Espace étude", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack()
        btn = Button(frame, text="Espace étudiants", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn.config(command=self.StudentsRoom)
        btn.pack(pady=(50, 10), fill=X)
        btn1 = Button(frame, text="Cours", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn1.config(command=self.Course)
        from Elements.Salle import Salle
        from Elements.Professeur import Professeur
        if len(Salle(0,'').getRooms()) == 0 or len(Professeur(0,'','','').getProfessors()) == 0:
            btn1.config(state=DISABLED)
        btn1.pack(pady=10, fill=X)
        btn2 = Button(frame, text="Espace professeurs", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn2.config(command=self.ProfRoom)
        btn2.pack(pady=10, fill=X)
        btn3 = Button(frame, text="Retour", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn3.config(command=lambda: self.Back())
        btn3.pack(pady=10, fill=X)
        frame.pack(expand=YES)
        # Affichage
        self.window.mainloop()

    def StudentsRoom(self):
        self.window.destroy()
        from UI.StudentSpace import StudentSpace
        StudentSpace()

    def Back(self):
        self.window.destroy()
        from UI.MainMenu import MainMenu
        MainMenu()

    def Course(self):
        self.window.destroy()
        from UI.Course import Course
        Course()

    def ProfRoom(self):
        self.window.destroy()
        from UI.ProfRoom import ProfRoom
        ProfRoom()