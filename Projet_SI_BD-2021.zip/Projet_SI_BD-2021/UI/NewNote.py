from tkinter import *
from tkinter import ttk

from Elements.Note import Note


class NewNote:
    def __init__(self):
        # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        Label(frame, text="Nouvelle note", font=("Courrier", 40), bg='#41B77F', fg='white').pack()
        frame1 = Frame(frame,bg='#41B77F')
        Label(frame1, text="id etudiant", font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=0,column=0,pady=10)
        idetud = Entry(frame1, font=("Courrier", 20), fg='#41B77F', bg='white')
        idetud.grid(row=0,column=1)
        Label(frame1, text="Matière", font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=1, column=0,pady=10)
        selectedProf = StringVar()
        selectedProf.set('----------Choisissez----------')
        from Elements.Matiere import Matiere
        m = [m.getMatiereName() for m in Matiere(0,'',0).getMatieres()]
        mEntry = ttk.Combobox(frame1, textvariable=selectedProf, font=("Courrier", 20))
        mEntry.config(foreground='#41B77F', background='white')
        mEntry['state'] = 'readonly'
        mEntry['values'] = m
        mEntry.grid(row=1,column=1,pady=10)
        Label(frame1, text="Note", font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=2, column=0,pady=10)
        note = Spinbox(frame1, font=("Courrier", 20), from_=0, to=20, wrap=True, state='readonly', justify=CENTER)
        note.grid(row=2, column=1, sticky='W')
        btn = Button(frame1, text="Enregistrer", font=("Courrier", 20), bg='#41B77F', fg='white')
        btn.config(command=lambda :self.Add(idetud.get(),mEntry.get(),note.get()))
        btn.grid(row=3,column=0,pady=10)
        btn1 = Button(frame1, text="Retour", font=("Courrier", 20), bg='#41B77F', fg='white')
        btn1.config(command=self.Back)
        btn1.grid(row=3, column=1,pady=10)
        frame1.pack(expand=YES)
        frame.pack(expand=YES)
        self.window.mainloop()

    def Add(self, idE, matiere, note):
        Note(0,idE,matiere,int(note)).Save()
        self.Back()

    def Back(self):
        self.window.destroy()
        from UI.Notes import Notes
        Notes()