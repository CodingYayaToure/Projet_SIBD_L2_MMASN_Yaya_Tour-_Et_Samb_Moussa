from tkinter import *

class ListProf:
    def __init__(self):
        # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        frame.pack(expand=YES,fill=BOTH)
        label_title = Label(frame, text="Liste des professeurs", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack()
        canvas = Canvas(frame, bg='#41B77F')
        canvas.pack(side=LEFT,fill=BOTH,expand=YES)
        vsc = Scrollbar(frame,orient=VERTICAL,command=canvas.yview)
        vsc.pack(side=RIGHT,fill=Y)
        canvas.configure(yscrollcommand=vsc.set)
        canvas.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        fc = Frame(canvas,bg='#41B77F')
        canvas.create_window((0,0),window=fc,anchor='nw')
        # Titre
        header = Frame(fc, bg='#006400')
        Label(header, text="Nom", font=("Courrier", 23), bg='#006400', fg='white').grid(row=0, column=0, padx=(10, 50))
        Label(header, text="Prénom", font=("Courrier", 23), bg='#006400', fg='white').grid(row=0, column=1, padx=(10, 50))
        Label(header, text="Grade", font=("Courrier", 23), bg='#006400', fg='white').grid(row=0, column=2, padx=(10, 50))
        header.pack(fill=X,padx=10)
        frame1 = Frame(fc, bg='#41B77F')
        i = 1
        from Elements.Professeur import Professeur
        for e in Professeur(0, "", "", "").getProfessors():
            Label(frame1, text=e.getProfessor()["nom"], font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=i,
                                                                                                              column=0,
                                                                                                              padx=(10, 50))
            Label(frame1, text=e.getProfessor()["prenom"], font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=i,
                                                                                                                 column=1,
                                                                                                                 padx=(
                                                                                                                     10,
                                                                                                                     50))
            Label(frame1, text=e.getProfessor()["grade"], font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=i,
                                                                                                                column=2,
                                                                                                                padx=(
                                                                                                                    10,
                                                                                                                    50));
            i += 1
        frame1.pack(expand=YES, fill=X)
        btn = Button(self.window, text="Retour", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn.config(command=self.Back)
        btn.pack(side=BOTTOM,expand=YES, pady=10)

        self.window.mainloop()

    def Back(self):
        self.window.destroy()
        from UI.ProfRoom import ProfRoom
        ProfRoom()