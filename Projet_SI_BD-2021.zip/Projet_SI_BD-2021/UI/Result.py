from tkinter import *

class Result:
    def __init__(self):
        # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        # Titre
        label_title = Label(frame, text="Résultats", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack()
        btn = Button(frame, text="Matières", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn.config(command=self.Matiere)
        btn.pack(pady=(50, 10), fill=X)
        btn1 = Button(frame, text="Notes", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn1.config(command=self.Notes)
        from Elements.Salle import Salle
        from Elements.Professeur import Professeur
        if len(Salle(0, '').getRooms()) == 0 or len(Professeur(0, '', '', '').getProfessors()) == 0:
            btn1.config(state=DISABLED)
        btn1.pack(pady=10, fill=X)
        btn2 = Button(frame, text="Délibération", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn2.config(command=self.Deliberation)
        btn2.pack(pady=10, fill=X)
        btn3 = Button(frame, text="Retour", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn3.config(command=self.Back)
        btn3.pack(pady=10, fill=X)
        frame.pack(expand=YES)

    def Back(self):
        self.window.destroy()
        from UI.MainMenu import MainMenu
        MainMenu()

    def Matiere(self):
        self.window.destroy()
        from UI.MatiereSpace import MatiereSpace
        MatiereSpace()

    def Deliberation(self):
        self.window.destroy()

    def Notes(self):
        self.window.destroy()
        from UI.Notes import Notes
        Notes()