from tkinter import *

class MatiereSpace:
    def __init__(self):
        # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        # Titre
        label_title = Label(frame, text="Espace matière", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack()
        btn = Button(frame, text="Nouvelle matière", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn.config(command=self.New)
        btn.pack(pady=(50, 10), fill=X)
        btn1 = Button(frame, text="Liste matières", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn1.config(command=self.List)
        btn1.pack(pady=10, fill=X)
        btn2 = Button(frame, text="Retour", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn2.config(command=self.Back)
        btn2.pack(pady=10, fill=X)
        frame.pack(expand=YES)
        # Affichage
        self.window.mainloop()

    def Back(self):
        self.window.destroy()
        from UI.Result import Result
        Result()

    def New(self):
        self.window.destroy()
        from UI.NewMatiere import NewMatiere
        NewMatiere()

    def List(self):
        self.window.destroy()
        from UI.ListMatiere import ListMatiere
        ListMatiere()