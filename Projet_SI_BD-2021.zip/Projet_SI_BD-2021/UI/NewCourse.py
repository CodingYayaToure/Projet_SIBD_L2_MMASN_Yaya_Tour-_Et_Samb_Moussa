from datetime import datetime,time
from tkinter import *
from tkinter import ttk

from tkcalendar import Calendar


class NewCourse:
    def __init__(self):
        from Elements.Salle import Salle
        # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        # Titre
        label_title = Label(frame, text="Nouveau cours", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack()
        scr = Scrollbar(frame, orient='vertical')
        frame1 = Frame(scr, bg='#41B77F')
        cnlab = Label(frame1, text="Nom", font=("Courrier", 20), bg='#41B77F', fg='white')
        cnlab.grid(row=0, column=0, pady=10,sticky='W')
        cnEntry = Entry(frame1, font=("Courrier", 20), fg='#41B77F', bg='white')
        cnEntry.grid(row=0, column=1,columnspan=3, pady=10, padx=5)
        proflab=Label(frame1, text="Nom du professeur", font=("Courrier", 20), bg='#41B77F', fg='white')
        proflab.grid(row=1,column=0,pady=10,padx=5,sticky='W')
        selectedProf = StringVar()
        selectedProf.set('----------Choisissez----------')
        from Elements.Professeur import Professeur
        profs = Professeur(0,'','','').ListProf()
        profEntry= ttk.Combobox(frame1,textvariable=selectedProf,font=("Courrier", 20))
        profEntry.config(foreground='#41B77F', background='white')
        profEntry['state'] = 'readonly'
        profEntry['values'] = profs
        profEntry.grid(row=1,column=1,columnspan=3,pady=10,padx=5)
        Label(frame1, text="Salle de classe", font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=2,column=0,padx=10,pady=5,sticky='W')
        selectedroom=StringVar()
        selectedroom.set('----------Choisissez----------')
        rooms = Salle(0,'').ListFreeRooms()
        if len(rooms) == 0:
            selectedroom.set('Aucune salle disponible')
        classEntry = ttk.Combobox(frame1,textvariable=selectedroom,font=("Courrier", 20))
        classEntry.config(foreground='#41B77F',background='white')
        classEntry['state'] = 'readonly'
        classEntry['values'] = rooms
        classEntry.grid(row=2, column=1, pady=10, padx=5,columnspan=3)
        Label(frame1, text="Date", font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=3, column=0, padx=10, pady=5, sticky='W')
        cal = Calendar(frame1,selectmode='day',year=datetime.now().year,month=datetime.now().month,day=datetime.now().day)
        cal.grid(row=3,column=1,padx=10,pady=5,sticky='W')
        Label(frame1, text="Début du cours", font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=4, column=0, padx=10, pady=5,sticky='W')
        hsp = Spinbox(frame1,from_ = 8,to=18,wrap=True,state='readonly',justify=CENTER)
        hsp.grid(row=4,column=1,sticky='W')
        Label(frame1, text=":", font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=4, column=2, padx=10,pady=5, sticky='W')
        msp = Spinbox(frame1, from_=0, to=59, wrap=True, state='readonly', justify=CENTER)
        msp.grid(row=4, column=3, sticky='W')
        Label(frame1, text="Fin du cours", font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=5, column=0, padx=10,
                                                                                                   pady=5, sticky='W')
        hsp1 = Spinbox(frame1, from_=8, to=18, wrap=True, state='readonly', justify=CENTER)
        hsp1.config(command=lambda: self.dispo(cal,time(hour=int(hsp.get()),minute=int(msp.get())),time(hour=int(hsp1.get()),minute=int(msp1.get())),classEntry,rooms))
        hsp1.grid(row=5, column=1, sticky='W')
        Label(frame1, text=":", font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=5, column=2, padx=10, pady=5,
                                                                                      sticky='W')
        msp1 = Spinbox(frame1, from_=0, to=59, wrap=True, state='readonly', justify=CENTER)
        #msp1.config(command=lambda: dispo(cal,time(hour=int(hsp1.get()),minute=int(msp1.get())),classEntry,btn))
        msp1.grid(row=5, column=3, sticky='W')
         # Sauvegarder
        btn = Button(frame1, text="Enregistrer", font=("Courrier", 20), fg='#41B77F', bg='white')
        if len(Salle(0, '').getFreeRooms()) == 0:
            btn.config(state=DISABLED)
        btn.config(command=lambda: self.Add(cnEntry.get(),profEntry.get(),cal.get_date(),time(hour=int(hsp.get()),minute=int(msp.get())),classEntry.get(),time(hour=int(hsp1.get()),minute=int(msp1.get()))))
        btn.grid(row=6, column=1, pady=10,sticky='W')
        btn1 = Button(frame1, text="Retour", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn1.config(command=self.Back)
        btn1.grid(row=6, column=2, pady=10, padx=5,sticky='E')
        frame1.pack(expand=YES)
        scr.pack(expand=YES,padx=10,pady=10)
        frame.pack(expand=YES)
        self.window.mainloop()

    def dispo(self,cal,hd,hf,salle,rooms):
        hdd = datetime.strptime(cal.get_date()+" "+str(hd),'%d/%m/%Y %H:%M:%S')
        hdf=datetime.strptime(cal.get_date()+" "+str(hf),'%d/%m/%Y %H:%M:%S')
        print('salle: ' + salle.get())
        print(f"HhD:{hdd} HdF:{hdf}")
        from Elements.Cours import Cours
        c = Cours(0,'','',hdd,salle.get(),hdf)
        rooms.extend(c.Willfree())
        salle['values'] = rooms

    def Add(self, nom, prof, date, hd, salle, hf):
        hdd = datetime.strptime(date + " " + str(hd), '%d/%m/%Y %H:%M:%S')
        hff = datetime.strptime(date+" "+str(hf),'%d/%m/%Y %H:%M:%S')
        from Elements.Cours import Cours
        Cours(0,nom,prof,hdd,salle,hff).Save()
        self.Back()

    def Back(self):
        self.window.destroy()
        from UI.Course import Course
        Course()
