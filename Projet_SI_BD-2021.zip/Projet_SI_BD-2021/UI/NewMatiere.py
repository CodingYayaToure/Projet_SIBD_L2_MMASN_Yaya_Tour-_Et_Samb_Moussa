from tkinter import *

class NewMatiere:
    def __init__(self):
        # Création fenêtre
        self.window = Tk()
        # Attributs window
        self.window.title('Projet SI/BD 2021')
        self.window.minsize(700, 500)
        self.window.config(background='#41B77F')
        # Ajouter Frame
        frame = Frame(self.window, bg='#41B77F')
        # Titre
        label_title = Label(frame, text="Nouvel étudiant", font=("Courrier", 40), bg='#41B77F', fg='white')
        label_title.pack()
        frame1 = Frame(frame, bg='#41B77F')
        Label(frame1, text="Libellé", font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=0, column=0, pady=10)
        libelle = Entry(frame1, font=("Courrier", 20), fg='#41B77F', bg='white')
        libelle.grid(row=0, column=1, pady=10)
        Label(frame1, text="Coefficient", font=("Courrier", 20), bg='#41B77F', fg='white').grid(row=1, column=0, pady=10)
        coeff=Spinbox(frame1, font=("Courrier", 20),from_=1,to=100, wrap=True, state='readonly', justify=CENTER)
        coeff.grid(row=1, column=1, pady=10,padx=5)

        btn = Button(frame1, text="Valider", font=("Courrier", 20), fg='#41B77F', bg='white')
        # Sauvegarder
        btn.config(command=lambda: self.Save(libelle.get(), coeff.get()))
        btn.grid(row=2, column=0, pady=10)
        btn1 = Button(frame1, text="Retour", font=("Courrier", 20), fg='#41B77F', bg='white')
        btn1.config(command=self.Back)
        btn1.grid(row=2, column=1, pady=10, padx=5)
        frame1.pack(expand=YES)
        frame.pack(expand=YES)
        self.window.mainloop()

    def Save(self, lib, coef):
        from Elements.Matiere import Matiere
        Matiere(0,lib,coef).Save()
        self.Back()

    def Back(self):
        self.window.destroy()
        from UI.MatiereSpace import MatiereSpace
        MatiereSpace()