from Elements.Cours import Cours
from Elements.Database import Database
from datetime import datetime

class Salle(Database):
    def __init__(self,num,libelle,bdname="management.db"):
        self.num=num
        self.libelle=libelle
        Database.__init__(self,bdname)

    def __int__(self):
        Database.__init__(self, "management.db")

    #Recupération de l'information de la salle
    def getRoom(self):
        return{
            "num":self.num,
            "libelle":self.libelle
        }

    #Création de la table Salle
    def createRoomTable(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Salle(
            id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
            libelle TEXT
        )""")
        self.con.commit()

    #Enregistrer Salle
    def Save(self):
        self.createRoomTable()
        self.cursor.execute("""INSERT INTO Salle (libelle) values (:libelle)""",self.getRoom())
        self.con.commit()

    #Obtenir toutes les salles
    def getRooms(self):
        self.createRoomTable()
        self.cursor.execute("""SELECT *FROM Salle""")
        res = self.cursor.fetchall()
        if len(res) != 0:
            return [Salle(r[0],r[1]) for r in res]
        return []

    def isTableEmpty(self):
        return len(self.getRooms()) == 0

    def isFree(self):
        cours = Cours(0,'','',datetime.now(),'',datetime.now()).getCoursesBy(self.libelle)
        if len (cours) == 0:
            return True
        for c in cours:
            if c.getRoomName() == self.libelle:
                return False
        return True

    def getFreeRooms(self):
        rooms = self.getRooms()
        free=[]
        for room in rooms :
            if room.isFree():
                free.append(room)
        return free

    def getState(self):
        if self.isFree():
            return 'disponible'
        return 'occupée'

    def getLibelle(self):
        return self.libelle

    def getRoomBy(self,lib):
        self.createRoomTable()
        self.cursor.execute("""SELECT *FROM Salle WHERE libelle=?""", [lib])
        res = self.cursor.fetchone()
        return Salle(res[0],res[1])

    def ListFreeRooms(self):
        rooms = self.getFreeRooms()
        if len(rooms) == 0:
            return []
        return [r.getLibelle() for r in rooms]