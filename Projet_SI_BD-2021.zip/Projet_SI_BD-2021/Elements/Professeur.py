from Elements.Database import Database

class Professeur(Database):
    def __init__(self, id, nom, prenom, grade, bdname="management.db"):
        self.id = id
        self.nom = nom
        self.prenom = prenom
        self.grade = grade
        Database.__init__(self,bdname)

    #Stockage information professeur
    def getProfessor(self):
        return {
            "id":self.id,
            "nom":self.nom,
            "prenom":self.prenom,
            "grade":self.grade
        }
    #Création de la table Professeur
    def createProfessorTable(self):
        self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS Professeur(
                    id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
                    nom TEXT,
                    prenom TEXT,
                    grade TEXT
                )""")
        self.con.commit()

    #Enregistrement d'un professeur
    def Save(self):
        #Création de la table si elle n'existe pas
        self.createProfessorTable()
        self.cursor.execute("""INSERT INTO Professeur (
                    nom,prenom,grade) values (:nom,:prenom,:grade)""", self.getProfessor())
        self.con.commit()

    #Liste des professeurs
    def getProfessors(self):
        self.createProfessorTable()
        self.cursor.execute("SELECT * FROM Professeur")
        list = [Professeur(prof[0], prof[1], prof[2], prof[3]) for prof in self.cursor.fetchall()]
        return list

    def isTableEmpty(self):
        return len(self.getProfessors()) == 0

    def getFullname(self):
        return self.prenom+' '+self.nom

    def ListProf(self):
        pr=self.getProfessors()
        if len(pr) == 0:
            return []
        return [p.getFullname() for p in pr]