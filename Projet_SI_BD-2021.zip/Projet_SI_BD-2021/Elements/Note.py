from Elements.Database import Database


class Note(Database):
    def __init__(self,id,idetudiant,matiere,note):
        self.id = id
        self.idetudiant = idetudiant
        self.matiere = matiere
        self.note = note
        Database.__init__(self,'management.db')

    def createNoteTable(self):
        self.cursor.execute("""
                           CREATE TABLE IF NOT EXISTS Note(
                           id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
                           idEtudiant INTEGER UNIQUE,
                           matiere TEXT UNIQUE,
                           note INTEGER
                       )""")
        self.con.commit()

    def getNote(self):
        return {
            'id':self.id,
            'idetudiant': self.idetudiant,
            'matiere':self.matiere,
            'note':self.note
        }

    def Save(self):
        self.createTableMatiere()
        self.cursor.execute("""
                    INSERT INTO Note (idEtudiant,matiere,note) values
                    (:idetudiant,:matiere,:note)""", self.getNote())
        self.con.commit()

    def getNotesByM(self):
        self.createTableMatiere()
        self.cursor.execute("""
                            SELECT *FROM Note WHERE idEtudiant = ? and matiere=?""",[ self.idetudiant,self.matiere])
        res = self.cursor.fetchall()
        if len(res) == 0:
            return []
        return [Note(r[0],r[1],r[2],r[3]) for r in res]



