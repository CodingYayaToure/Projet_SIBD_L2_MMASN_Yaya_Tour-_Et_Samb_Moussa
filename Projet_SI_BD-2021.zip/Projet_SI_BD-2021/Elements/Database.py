import sqlite3

class Database:
    def __init__(self,bdname):
        self.con=sqlite3.connect(bdname)
        self.cursor=self.con.cursor()

