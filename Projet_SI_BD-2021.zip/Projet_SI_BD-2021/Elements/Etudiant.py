from Elements.Database import Database

class Etudiant (Database):
    def __init__(self,id,nom,prenom,niveau,dbname="management.db"):
        self.id=id
        self.nom=nom
        self.prenom=prenom
        self.niveau=niveau
        Database.__init__(self,dbname)


    #Stockage des informations d'un étudiant
    def getStudent(self):
        return {
            "id":self.id,
            "nom":self.nom,
            "prenom":self.prenom,
            "niveau":self.niveau
        }

    def Affichage(self):
        print(f"""id: {self.id}
                  nom: {self.nom}
                  prénom: {self.prenom}
                  niveau: {self.niveau}""")
        return f"{self.nom} | {self.prenom} | {self.niveau}"

    # Création de la table Etudiant
    def createStudentTable(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS Etudiant(
            id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
            nom TEXT,
            prenom TEXT,
            niveau TEXT
        )""")
        self.con.commit()

    def Save(self):
        #création de la table
        self.createStudentTable()
        self.cursor.execute("""INSERT INTO Etudiant (
            nom,prenom,niveau) values (:nom,:prenom,:niveau)""",self.getStudent())
        self.con.commit()
        print(self.cursor.lastrowid)


    def getStudents(self):
        self.createStudentTable()
        self.cursor.execute("SELECT * FROM Etudiant")
        list=[Etudiant(stud[0],stud[1],stud[2],stud[3]) for stud in self.cursor.fetchall()]
        return list

    def getEtudiantById(self,id):
        self.createStudentTable()
        self.cursor.execute(f"SELECT * FROM Etudiant WHERE id={id}")
        res=self.cursor.fetchone()
        return Etudiant(res[0],res[1],res[2],res[3])