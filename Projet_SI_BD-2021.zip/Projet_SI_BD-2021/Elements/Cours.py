from Elements.Database import Database
from datetime import datetime,time,date,timedelta

class Cours(Database):
    def __init__(self, id, nom, prof, debut, salle, fin):
        self.id = id
        self.nom = nom
        self.prof = prof
        self.debut = debut
        self.salle = salle
        self.fin = fin
        Database.__init__(self, "management.db")

    # Obtenir les informations d'un cours
    def getCourse(self):
        return {
            "nom": self.nom,
            "prof": self.prof,
            "debut": self.debut,
            "salle": self.salle,
            "fin": self.fin
        }

    def createCourseTable(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS Cours(
            id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
            nom TEXT,
            prof TEXT,
            debut timestamp,
            salle TEXT,
            fin timestamp
        )""")
        self.con.commit()

    def Save(self):
        self.createCourseTable()
        self.cursor.execute("""
            INSERT INTO Cours (nom,prof,debut,salle,fin) values
            (:nom,:prof,:debut,:salle,:fin)""", self.getCourse())
        self.con.commit()

    def getCourses(self):
        self.createCourseTable()
        self.cursor.execute("SELECT *FROM Cours")
        res = self.cursor.fetchall()
        if len(res) != 0:
            return [Cours(r[0], r[1], r[2], r[3], r[4],r[5]) for r in res]
        return []

    def getCoursesBy(self,libelle):
        if len(self.getCourses()) == 0:
            return []
        self.cursor.execute(f"SELECT * FROM Cours WHERE nom=?",[libelle])
        res = self.cursor.fetchall()
        print(res)
        if len(res) != 0:
            return [Cours(r[0], r[1], r[2], r[3], r[4], r[5]) for r in res]
        return []

    def PlaningFor(self,prof):
        self.createCourseTable()
        self.cursor.execute(f"SELECT *FROM Cours WHERE prof=?",[prof])
        res = self.cursor.fetchall()
        if len(res) != 0:
            return [Cours(r[0], r[1], r[2], r[3], r[4], r[5]) for r in res]
        return []

    def getRoomName(self):
        return self.salle

    def getDebut(self):
        return datetime.strptime(str(self.debut), '%Y-%m-%d %H:%M:%S')

    def getFin(self):
        return datetime.strptime(self.fin,'%Y-%m-%d %H:%M:%S')

    def isPossible(self):
        cours = self.getCoursesBy(self.nom)
        for c in cours:
            print(f"HD:{self.getDebut()}  HF:{self.getFin()}")
            if (c.getDebut() < self.getFin() < c.getFin()) or (c.getDebut() < self.getDebut() < c.getFin()):
                return False
        return True

    def getNom(self):
        return self.nom

    def getProf(self):
        return self.prof

    def getSalle(self):
        return self.salle

    def getDate(self):
        return self.getDebut().date()

    def getTDebut(self):
        return self.getDebut().time()

    def getTFin(self):
        return self.getFin().time()

    def getHoraire(self):
        return str(self.getTDebut())+'-'+str(self.getTFin())

    def setSalle(self,nom):
        self.salle=nom
    def getOccupedRooms(self):
        if len(self.getCourses()) == 0:
            return []
        return [c.getSalle() for c in self.getCourses()]

    def Willfree(self):
        rooms = self.getOccupedRooms()
        l = []
        for r in rooms:
            self.setSalle(r)
            if(self.isPossible()):
                l.append(r)
        return r
