from Elements.Database import Database

class Matiere(Database):
    def __init__(self,code,libelle,coeff):
        self.code = code
        self.libelle = libelle
        self.coeff = coeff
        Database.__init__(self,'management.db')

    def getMatiere(self):
        return {
            "code": self.code,
            "libelle": self.libelle,
            "coeff": self.coeff
        }

    def createTableMatiere(self):
        self.cursor.execute("""
                   CREATE TABLE IF NOT EXISTS Matiere(
                   code INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE,
                   libelle TEXT UNIQUE,
                   coeff INTEGER
               )""")
        self.con.commit()

    def Save(self):
        self.createTableMatiere()
        self.cursor.execute("""
            INSERT INTO Matiere (code,libelle,coeff) values
            (:code,:libelle,:coeff)""", self.getMatiere())
        self.con.commit()

    def getMatieres(self):
        self.createTableMatiere()
        self.cursor.execute("""SELECT * FROM Matiere""")
        res = self.cursor.fetchall()
        if len(res) == 0:
            return []
        return [Matiere(r[0],r[1],r[2]) for r in res]

    def getMatiereName(self):
        return self.libelle


