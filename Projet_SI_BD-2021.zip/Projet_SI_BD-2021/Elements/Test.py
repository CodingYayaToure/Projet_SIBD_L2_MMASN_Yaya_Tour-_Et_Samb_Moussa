from tkinter import *

root = Tk()
root.geometry("500x500")
main_frame = Frame(root)
main_frame.pack(fill=BOTH,expand=YES)
canvas = Canvas(main_frame)
canvas.pack(fill=BOTH,side=LEFT,expand=YES)
scr = Scrollbar(main_frame, orient=VERTICAL,command=canvas.yview)
scr.pack(fill=Y,side=RIGHT)
canvas.configure(yscrollcommand=scr.set)
canvas.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
frame = Frame(canvas)
canvas.create_window((0,0),window = frame,anchor='nw')
for i in range(100):
   Button(frame,text=f"Button {(i+1)}").pack(expand=YES)

root.mainloop()



