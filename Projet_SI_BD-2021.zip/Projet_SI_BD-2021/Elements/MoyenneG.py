
class MoyenneG:
    def __init__(self):
        pass