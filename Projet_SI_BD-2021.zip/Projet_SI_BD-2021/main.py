from UI.MainMenu import MainMenu

if __name__ == '__main__':
    MainMenu()
